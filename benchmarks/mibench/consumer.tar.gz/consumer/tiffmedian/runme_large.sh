#!/bin/sh
../tiff-v3.5.4/tools/tiffmedian ../tiff-data/large.tif output_largemedian.tif
