#!/bin/sh
lame3.70/lame large.wav output_large.mp3
