#!/bin/sh
lame3.70/lame small.wav output_small.mp3
