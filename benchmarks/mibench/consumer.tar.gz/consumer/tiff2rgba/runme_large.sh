#!/bin/sh
../tiff-v3.5.4/tools/tiff2rgba -c none ../tiff-data/large.tif output_largergba.tif
