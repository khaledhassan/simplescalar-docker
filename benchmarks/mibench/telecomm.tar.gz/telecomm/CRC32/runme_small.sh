#!/bin/sh
crc ../adpcm/data/large.pcm > output_small.txt
